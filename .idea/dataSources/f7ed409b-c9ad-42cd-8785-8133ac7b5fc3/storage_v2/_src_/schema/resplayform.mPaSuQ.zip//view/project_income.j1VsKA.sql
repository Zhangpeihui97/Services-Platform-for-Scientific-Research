create view project_income as
  select `resplayform`.`income`.`payment_unit` AS `payment_unit`,
         `resplayform`.`income`.`money`        AS `money`,
         `resplayform`.`income`.`operator`     AS `operator`,
         `resplayform`.`income`.`date`         AS `date`,
         `resplayform`.`project`.`leader`      AS `leader`,
         `resplayform`.`project`.`name`        AS `name`,
         `resplayform`.`project`.`number`      AS `number`,
         `resplayform`.`project`.`institution` AS `institution`,
         `resplayform`.`project`.`lever`       AS `lever`,
         `resplayform`.`project`.`budget`      AS `budget`,
         `resplayform`.`project`.`start_time`  AS `start_time`,
         `resplayform`.`project`.`end_time`    AS `end_time`,
         `resplayform`.`income`.`id`           AS `id`
  from (`resplayform`.`income` join `resplayform`.`project` on ((`resplayform`.`income`.`pid` =
                                                                 `resplayform`.`project`.`id`)));

