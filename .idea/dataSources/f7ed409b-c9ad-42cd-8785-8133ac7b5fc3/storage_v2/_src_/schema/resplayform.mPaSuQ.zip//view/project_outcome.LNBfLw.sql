create view project_outcome as
  select `resplayform`.`outcome`.`id`         AS `id`,
         `resplayform`.`outcome`.`pid`        AS `pid`,
         `resplayform`.`outcome`.`operator`   AS `operator`,
         `resplayform`.`outcome`.`apply_user` AS `apply_user`,
         `resplayform`.`outcome`.`purpose`    AS `purpose`,
         `resplayform`.`outcome`.`money`      AS `money`,
         `resplayform`.`outcome`.`date`       AS `date`,
         `resplayform`.`project`.`name`       AS `name`,
         `resplayform`.`project`.`leader`     AS `leader`
  from (`resplayform`.`project` join `resplayform`.`outcome` on ((`resplayform`.`project`.`id` =
                                                                  `resplayform`.`outcome`.`pid`)));

