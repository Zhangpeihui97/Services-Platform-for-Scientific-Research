create view project_fund as
  select `resplayform`.`project`.`id`          AS `id`,
         `f`.`id`                              AS `FId`,
         `f`.`money`                           AS `FMoney`,
         `f`.`total_money`                     AS `FTotalMoney`,
         `f`.`payment_unit`                    AS `FPaymentUnit`,
         `f`.`date`                            AS `FDate`,
         `resplayform`.`project`.`name`        AS `name`,
         `resplayform`.`project`.`lever`       AS `lever`,
         `resplayform`.`project`.`number`      AS `number`,
         `resplayform`.`project`.`leader`      AS `leader`,
         `resplayform`.`project`.`budget`      AS `budget`,
         `resplayform`.`project`.`start_time`  AS `start_time`,
         `resplayform`.`project`.`end_time`    AS `end_time`,
         `resplayform`.`project`.`apply_time`  AS `apply_time`,
         `resplayform`.`project`.`institution` AS `institution`,
         `resplayform`.`project`.`state`       AS `state`
  from (`resplayform`.`fund` `f` join `resplayform`.`project` on ((`f`.`pid` = `resplayform`.`project`.`id`)));

